<div data-role="footer" data-position="fixed">
	<h4>jQuery Mobile App :: Geolocation</h4>
</div><!-- /footer -->