<div data-role="header">
	<h1>Geolocation</h1>
	<div data-role="navbar">
		<ul>
			<li><a href="#homePage">Geolocation</a></li>
			<li><a href="#mapPage">Map</a></li>
			<li><a href="#directionsPage">Directions</a></li>
		</ul>
	</div><!-- /navbar -->
</div><!-- /header -->