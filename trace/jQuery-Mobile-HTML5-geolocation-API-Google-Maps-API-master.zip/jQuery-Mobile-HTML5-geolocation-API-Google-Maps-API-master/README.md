# jQuery-Mobile-HTML5-geolocation-API-Google-Maps-API
2014 teaching resource for an app

You can see a demo here: https://micromediaweb.com/home/nortonb/common/jquery_mobile_geolocation/
Please sign up for your own API key
https://console.developers.google.com/apis/library/maps-backend.googleapis.com/

See the accompanying videos here:
https://youtu.be/W0juXNFLd6w
